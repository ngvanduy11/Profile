import { connectLanyardWs, currentPresence, updatePresenceProfile } from './presence/presence.js';
import { openLyrics, closeLyrics, updateLyricsHighlight } from './lyrics/lyrics.js';
import { fmt, setSpin, syncPlayUI, tryPlay, loadTrack, setupPlayer, syncSpotifyAudio, clearSpotifySync, getCurrentTrack, currentIndex } from './spotify/player.js';
import { loadCursorEffect } from './cursor/cursorEffectsShared.js';
import { initDonate, openDonateModal } from './donate/donate.js';

window.loadCursorEffect = loadCursorEffect;

let userId = "375027179358257152";
let backgroundUrl = "";
let backgroundBlur = 0;
let avatarOverride = "";
let avatarDecOverride = "";
let nameOverride = "";
let customSocials = [];
let customBios = [];
let guildInvite = '';
let rpcAddFriendLink = '';
let guildWidgetPlacement = 'inside';
let isMusicRandom = false;
let apiReady = false;

const cc = document.getElementById('cc');
const ctx2 = cc.getContext('2d');
cc.width = window.innerWidth;
cc.height = window.innerHeight;
window.addEventListener('resize', () => {
    cc.width = window.innerWidth;
    cc.height = window.innerHeight;
});

const pts = [];
class TrailPoint {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.vx = (Math.random() - .5) * .7;
        this.vy = (Math.random() - .5) * .7;
        this.l = 1;
        this.sz = Math.random() * 1.6 + .3;
    }
    up() {
        this.x += this.vx;
        this.y += this.vy;
        this.l -= .024;
        this.sz = Math.max(0, this.sz - .015);
    }
    dr() {
        ctx2.globalAlpha = this.l * .3;
        ctx2.fillStyle = '#fff';
        ctx2.beginPath();
        ctx2.arc(this.x, this.y, this.sz, 0, Math.PI * 2);
        ctx2.fill();
    }
}

document.addEventListener('mousemove', e => {
    if (pts.length < 80) pts.push(new TrailPoint(e.clientX, e.clientY));
});

(function renderLoop() {
    requestAnimationFrame(renderLoop);
    ctx2.clearRect(0, 0, cc.width, cc.height);
    ctx2.globalAlpha = 1;
    for (let i = pts.length - 1; i >= 0; i--) {
        pts[i].up();
        pts[i].dr();
        if (pts[i].l <= 0) pts.splice(i, 1);
    }
})();

function updateClock() {
    const el = document.getElementById('clock');
    if (!el) return;
    const parts = {};
    new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Ho_Chi_Minh',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    }).formatToParts(new Date()).forEach(x => {
        parts[x.type] = x.value;
    });
    el.textContent = (parts.hour || '00') + ':' + (parts.minute || '00') + ':' + (parts.second || '00');
}
updateClock();
setInterval(updateClock, 1000);

let titleText = '@bio';
let titleIndex = 0;
let titleDirection = false;
function animTitle() {
    document.title = titleDirection ? titleText.substring(0, titleIndex--) : titleText.substring(0, ++titleIndex);
    if (!titleDirection && titleIndex === titleText.length) {
        titleDirection = true;
        setTimeout(animTitle, 2200);
        return;
    }
    if (titleDirection && titleIndex === 0) {
        titleDirection = false;
        setTimeout(animTitle, 600);
        return;
    }
    setTimeout(animTitle, 340);
}
animTitle();

window.applyBackground = function (customUrl) {
    const bg = document.getElementById('bg');
    const existingMedia = document.getElementById('bg-media');
    const filterString = backgroundBlur > 0 ? 'brightness(.52) saturate(.68) blur(' + backgroundBlur + 'px)' : 'none';
    const filterStyle = 'filter:' + filterString + '; transform:' + (backgroundBlur > 0 ? 'scale(1.1)' : 'scale(1)') + ';';
    if (existingMedia && existingMedia.dataset.src === (customUrl || 'default')) {
        existingMedia.style.filter = filterString;
        existingMedia.style.transform = backgroundBlur > 0 ? 'scale(1.1)' : 'scale(1)';
        return;
    }
    if (existingMedia) existingMedia.remove();
    const bgStyleBase = 'position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity 1.4s ease, filter 0.5s ease, transform 0.5s ease;pointer-events:none;z-index:0;';
    if (customUrl) {
        const isVideo = customUrl.match(/\.(mp4|webm|ogg)$/i) || customUrl.startsWith('data:video');
        if (isVideo) {
            const v = document.createElement('video');
            v.id = 'bg-media';
            v.dataset.src = customUrl;
            v.autoplay = true;
            v.loop = true;
            v.muted = true;
            v.playsInline = true;
            v.setAttribute('playsinline', '');
            v.preload = 'auto';
            v.style.cssText = bgStyleBase + filterStyle;
            v.oncanplay = function () {
                this.style.opacity = '1';
                if (this.play) this.play().catch(() => {});
            };
            v.onloadeddata = v.oncanplay;
            const checkInterval = setInterval(() => {
                if (!document.getElementById('bg-media')) {
                    clearInterval(checkInterval);
                    return;
                }
                if (v.paused) return;
                if (v.duration && !isNaN(v.duration) && v.duration > 0.6) {
                    if (v.currentTime >= v.duration - 0.35) {
                        v.currentTime = 0;
                        v.play().catch(() => {});
                    }
                }
            }, 40);
            v.src = customUrl;
            bg.appendChild(v);
        } else {
            const img = document.createElement('img');
            img.id = 'bg-media';
            img.dataset.src = customUrl;
            img.style.cssText = bgStyleBase + filterStyle;
            img.onload = function () {
                this.style.opacity = '1';
            };
            img.src = customUrl;
            bg.appendChild(img);
        }
    }
};

window.applyBackground();

function applyStyleConfig(style) {
    if (!style) return;
    const nameColor = style.nameColor || '#ffffff';
    const bioColor = style.bioColor || 'rgba(255,255,255,0.55)';
    const iconColor = style.iconColor || 'rgba(255,255,255,0.2)';
    const nameGlow = style.nameGlow || false;
    const nameEl = document.getElementById('c-name');
    if (nameEl && !nameEl.classList.contains('text-rainbow') && !nameEl.classList.contains('text-shine') && !nameEl.classList.contains('text-glitch')) {
        nameEl.style.color = nameColor;
    }
    const bioEl = document.querySelector('.c-bio');
    if (bioEl) bioEl.style.color = bioColor;
    document.querySelectorAll('.c-socials a').forEach(el => el.style.color = iconColor);
    if (nameGlow && nameEl) nameEl.style.textShadow = '0 0 16px ' + nameColor;
    else if (nameEl) nameEl.style.textShadow = '0 0 15px rgba(255,255,255,0.8), 0 0 30px rgba(255,255,255,0.4)';
}

let nameEffectActive = false;
let nameWaveActive = false;
let layoutConfig = null;

function applyLayout(layout) {
    if (!layout) return;
    const nameEl = document.getElementById('c-name');
    if (layout.nameEffect && layout.nameEffect !== 'none' && nameEl) {
        nameEl.style.animation = '';
        nameEl.style.backgroundImage = '';
        nameEl.style.backgroundSize = '';
        nameEl.style.webkitBackgroundClip = '';
        nameEl.style.backgroundClip = '';
        nameEl.style.webkitTextFillColor = '';
    } else if (nameEl) {
        nameEl.style.animation = '';
        nameEl.style.backgroundImage = '';
        nameEl.style.backgroundSize = '';
        nameEl.style.webkitBackgroundClip = '';
        nameEl.style.backgroundClip = '';
        nameEl.style.webkitTextFillColor = '';
    }
    layoutConfig = layout;
    if (layout.bgEffect === 'particles') loadParticlesEffect();
    if (layout.cursorEffect && typeof window.loadCursorEffect === 'function') {
        window.loadCursorEffect(layout.cursorEffect, window.currentConfig?.general?.cursorEffectColor);
    }
    if (layout.customFontUrl && layout.customFontName) {
        const fontFace = new FontFace(layout.customFontName, 'url(' + layout.customFontUrl + ')');
        fontFace.load().then(function (font) {
            document.fonts.add(font);
            document.body.style.fontFamily = "'" + layout.customFontName + "', var(--f-sans)";
        }).catch(() => {});
    }
}

function applyNameEffect(effectType) {
    if (!effectType || effectType === 'none') return;
    const el = document.getElementById('c-name');
    if (!el || !el.textContent.trim() || el.textContent.trim() === 'Loading...') return;
    if (nameEffectActive) return;
    nameEffectActive = true;
    if (effectType === 'shine') {
        const text = el.textContent.trim();
        el.innerHTML = '';
        for (let i = 0; i < text.length; i++) {
            const span = document.createElement('span');
            span.textContent = text[i] === ' ' ? '\u00A0' : text[i];
            span.style.display = 'inline-block';
            span.style.animation = 'namePulse 2s linear infinite';
            span.style.animationDelay = (i * 0.1) + 's';
            el.appendChild(span);
        }
    } else if (effectType === 'rainbow') {
        el.style.animation = 'nameNeon 4s ease-in-out infinite';
    } else if (effectType === 'glitch') {
        el.style.animation = 'nameGlitch 0.3s infinite';
    } else if (effectType === 'wave') {
        const text = el.textContent.trim();
        el.innerHTML = '';
        const spans = [];
        for (let i = 0; i < text.length; i++) {
            const span = document.createElement('span');
            span.textContent = text[i] === ' ' ? '\u00A0' : text[i];
            span.style.display = 'inline-block';
            span.style.opacity = '0.5';
            el.appendChild(span);
            spans.push(span);
        }
        const totalChars = spans.length;
        const waves = [];
        function waveCreate() {
            waves.push({
                position: 0,
                speed: 0.06
            });
        }
        function waveAnimate() {
            for (let i = waves.length - 1; i >= 0; i--) {
                waves[i].position += waves[i].speed;
                if (waves[i].position > totalChars + 3) waves.splice(i, 1);
            }
            for (let idx = 0; idx < spans.length; idx++) {
                let intensity = 0;
                for (let w = 0; w < waves.length; w++) {
                    const dist = Math.abs(idx - waves[w].position);
                    if (dist < 3) intensity += Math.cos((dist / 3) * Math.PI / 2);
                }
                intensity = Math.min(1, Math.max(0, intensity));
                spans[idx].style.opacity = (0.5 + intensity * 0.5).toString();
                spans[idx].style.transform = 'scale(' + (1 + intensity * 0.1) + ')';
                spans[idx].style.textShadow = intensity > 0 ? '0 0 ' + (intensity * 10) + 'px' : '';
            }
            requestAnimationFrame(waveAnimate);
        }
        waveCreate();
        waveAnimate();
        setInterval(waveCreate, 2000);
    } else if (effectType === 'typewrite') {
        const originalText = el.textContent.trim();
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*';
        const writeSpeed = 50;
        const eraseSpeed = 60;
        const scrambleDelay = 60;
        const scrambleFrames = 5;
        const loopDelay = 3500;
        async function scrambleCurrent(targetText) {
            for (let f = 0; f < scrambleFrames; f++) {
                let output = '';
                for (let i = 0; i < targetText.length; i++) {
                    if (Math.random() < 0.3) output += chars[Math.floor(Math.random() * chars.length)];
                    else output += targetText[i];
                }
                el.textContent = output;
                await new Promise(r => setTimeout(r, scrambleDelay));
            }
            el.textContent = targetText;
        }
        async function writeText(str) {
            let current = '';
            for (let i = 0; i < str.length; i++) {
                current += str[i];
                await scrambleCurrent(current);
                await new Promise(r => setTimeout(r, writeSpeed));
            }
        }
        async function eraseText() {
            let current = el.textContent;
            while (current.length > 0) {
                current = current.slice(0, -1);
                el.textContent = current;
                await new Promise(r => setTimeout(r, eraseSpeed));
            }
        }
        (async function typeLoop() {
            while (true) {
                await writeText(originalText);
                await new Promise(r => setTimeout(r, loopDelay));
                await eraseText();
                await new Promise(r => setTimeout(r, 100));
            }
        })();
    }
}

function loadParticlesEffect() {
    if (document.querySelector('.particles-container')) return;
    const container = document.createElement('div');
    container.className = 'particles-container';
    for (let i = 0; i < 50; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.left = Math.random() * 100 + '%';
        p.style.animationDuration = (Math.random() * 8 + 4) + 's';
        p.style.animationDelay = (Math.random() * 5) + 's';
        p.style.width = (Math.random() * 2 + 1) + 'px';
        p.style.height = p.style.width;
        p.style.opacity = Math.random() * 0.5 + 0.2;
        container.appendChild(p);
    }
    document.body.appendChild(container);
}

function applyCustomSettings(config) {
    if (config.general) {
        if (config.general.cursorUrl) {
            let cursorStyle = document.getElementById('custom-cursor-style');
            if (!cursorStyle) {
                cursorStyle = document.createElement('style');
                cursorStyle.id = 'custom-cursor-style';
                document.head.appendChild(cursorStyle);
            }
            cursorStyle.textContent = `* { cursor: url('${config.general.cursorUrl}'), auto !important; }`;
        }
        if (config.general.customFont) {
            const fontVal = config.general.customFont.trim();
            if (fontVal === 'Outfit') {
                document.documentElement.style.setProperty('--f-serif', 'var(--f-sans)');
                document.body.style.fontFamily = 'var(--f-sans)';
                document.querySelectorAll('.c-discord-activity, .c-discord-detail, .c-discord-name').forEach(el => el.style.setProperty('font-family', "'Outfit', sans-serif", 'important'));
            } else if (fontVal === 'Inter') {
                const link = document.createElement('link');
                link.href = `https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap`;
                link.rel = 'stylesheet';
                document.head.appendChild(link);
                document.documentElement.style.setProperty('--f-sans', "'Inter', sans-serif");
                document.body.style.fontFamily = "'Inter', sans-serif";
                const nameBioEls = document.querySelectorAll('#hero-name, #c-name, .hero-name, .c-name, .ez-name, #custom-bios, #c-bio, .bio-text, .c-bio, .ez-bio, .ov-name');
                nameBioEls.forEach(el => {
                    if (el) el.style.setProperty('font-family', 'var(--f-serif)', 'important');
                });
                document.querySelectorAll('.c-discord-activity, .c-discord-detail, .c-discord-name').forEach(el => el.style.setProperty('font-family', "'Outfit', sans-serif", 'important'));
            } else if (fontVal.startsWith('http')) {
                const fontFace = new FontFace('GeneralCustomFont', `url(${fontVal})`);
                fontFace.load().then(font => {
                    document.fonts.add(font);
                    document.documentElement.style.setProperty('--f-sans', "'GeneralCustomFont', sans-serif");
                    document.documentElement.style.setProperty('--f-serif', "'GeneralCustomFont', sans-serif");
                    document.documentElement.style.setProperty('--f-mono', "'GeneralCustomFont', sans-serif");
                    document.body.style.fontFamily = "'GeneralCustomFont', sans-serif";
                }).catch(e => console.warn('General custom font load failed', e));
            } else {
                const link = document.createElement('link');
                link.href = `https://fonts.googleapis.com/css2?family=${fontVal.replace(/ /g, '+')}:wght@300;400;500;600;700&display=swap`;
                link.rel = 'stylesheet';
                document.head.appendChild(link);
                document.documentElement.style.setProperty('--f-sans', `'${fontVal}', sans-serif`);
                document.documentElement.style.setProperty('--f-serif', `'${fontVal}', sans-serif`);
                document.documentElement.style.setProperty('--f-mono', `'${fontVal}', sans-serif`);
                document.body.style.fontFamily = `'${fontVal}', sans-serif`;
            }
        }
    }
    if (config.widgets) {
        let widgetStyle = document.getElementById('custom-widget-style');
        if (!widgetStyle) {
            widgetStyle = document.createElement('style');
            widgetStyle.id = 'custom-widget-style';
            document.head.appendChild(widgetStyle);
        }
        if (config.widgets.showDiscordRPC === false) {
            widgetStyle.textContent = '#c-discord-card, #discord-card, #ez-discord-card, .c-discord-top, .discord-presence, .info-card:has(#discord-card), .c-card:has(#c-discord-av) { display: none !important; }';
        } else {
            widgetStyle.textContent = '';
        }
    }
    if (config.musicWidget === false) {
        let musicVisStyle = document.getElementById('custom-music-vis-style');
        if (!musicVisStyle) {
            musicVisStyle = document.createElement('style');
            musicVisStyle.id = 'custom-music-vis-style';
            document.head.appendChild(musicVisStyle);
        }
        musicVisStyle.textContent = '.music-inner, .c-music { display: none !important; }';
    } else {
        let musicVisStyle = document.getElementById('custom-music-vis-style');
        if (musicVisStyle) musicVisStyle.textContent = '';
    }
    if (config.border) {
        let borderStyle = document.getElementById('custom-border-style');
        if (!borderStyle) {
            borderStyle = document.createElement('style');
            borderStyle.id = 'custom-border-style';
            document.head.appendChild(borderStyle);
        }
        const selectors = '.content-container, .about-inner, .ez-card-wrap, #c-guild-card.outside';
        let css = '';
        if (config.border.style === 'shimmer') {
            const bw = config.border.width !== undefined ? config.border.width : 1;
            const br = config.border.radius !== undefined ? config.border.radius : 26;
            const bc = (config.border.color && config.border.color !== 'rgba(255, 255, 255, 0.4)') ? config.border.color : 'var(--border-color)';
            css += `@property --shimmer-angle { syntax: '<angle>'; initial-value: 0deg; inherits: true; } `;
            css += `@keyframes shimmer-spin { to { --shimmer-angle: 360deg; } } `;
            css += `:root { animation: shimmer-spin 8s linear infinite; } `;
            css += `${selectors} { position: relative; border: ${bw}px solid var(--wdd) !important; border-radius: ${br}px !important; transition: box-shadow 0.3s ease, border-color 0.3s ease; } `;
            const hoverSelectors = selectors.split(',').map(s => s.trim() + ':hover').join(', ');
            css += `${hoverSelectors} { border-color: var(--wd) !important; } `;
            const afterSelectors = selectors.split(',').map(s => s.trim() + '::after').join(', ');
            css += `${afterSelectors} { content: ""; position: absolute; inset: -${bw}px; border-radius: ${br}px; padding: ${bw}px; background: conic-gradient(from var(--shimmer-angle), transparent 70%, ${bc} 100%); -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0); -webkit-mask-composite: xor; mask-composite: exclude; pointer-events: none; z-index: 10; } `;
        } else if (config.border.style === 'solid') {
            const bc = (config.border.color && config.border.color !== '#ffffff') ? config.border.color : 'var(--border-color)';
            css += `${selectors} { border: ${config.border.width !== undefined ? config.border.width : 1}px solid ${bc} !important; border-radius: ${config.border.radius !== undefined ? config.border.radius : 26}px !important; }`;
        }
        borderStyle.textContent = css;
        document.querySelectorAll('.about-inner, .ez-card-wrap').forEach(el => el.classList.add('content-container'));
    }
    if (config.general) {
        const cards = document.querySelectorAll('.ez-card-wrap, #c-guild-card');
        cards.forEach(card => {
            if (config.general.card3d) {
                if (!card.dataset.has3d) {
                    card.dataset.has3d = 'true';
                    card.style.transformStyle = 'preserve-3d';
                    let rafId = null;
                    let rect = null;
                    card.addEventListener('mouseenter', () => {
                        if (card.dataset.has3d !== 'true') return;
                        card.style.transition = 'transform 0.1s ease-out';
                        rect = card.getBoundingClientRect();
                    });
                    card.addEventListener('mousemove', e => {
                        if (card.dataset.has3d !== 'true') return;
                        if (!card.style.transition.includes('0.1s')) card.style.transition = 'transform 0.1s ease-out';
                        if (card.id === 'c-guild-card' && !card.classList.contains('outside')) {
                            card.style.transform = 'none';
                            return;
                        }
                        if (!rect) rect = card.getBoundingClientRect();
                        if (rafId) cancelAnimationFrame(rafId);
                        rafId = requestAnimationFrame(() => {
                            const x = e.clientX - rect.left - rect.width / 2;
                            const y = e.clientY - rect.top - rect.height / 2;
                            card.style.transform = `perspective(1000px) rotateX(${-(y / rect.height) * 10}deg) rotateY(${(x / rect.width) * 10}deg)`;
                        });
                    });
                    card.addEventListener('mouseleave', () => {
                        if (card.dataset.has3d !== 'true') return;
                        if (rafId) cancelAnimationFrame(rafId);
                        card.style.transition = 'transform 0.4s ease-out';
                        card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
                        setTimeout(() => {
                            if (card.dataset.has3d === 'true') card.style.transition = '';
                        }, 400);
                        rect = null;
                    });
                }
            } else {
                if (card.dataset.has3d) {
                    card.dataset.has3d = 'false';
                    card.style.transform = 'none';
                }
            }
        });
        if (config.general.cardOpacity !== undefined || config.general.cardBlur !== undefined) {
            let cardStyle = document.getElementById('custom-card-bg-style');
            if (!cardStyle) {
                cardStyle = document.createElement('style');
                cardStyle.id = 'custom-card-bg-style';
                document.head.appendChild(cardStyle);
            }
            const opacity = config.general.cardOpacity !== undefined ? config.general.cardOpacity / 100 : 0.4;
            const blur = config.general.cardBlur !== undefined ? config.general.cardBlur : 12;
            cardStyle.textContent = `:root { --card-bg: rgba(var(--card-bg-base), ${opacity}) !important; } .compact-wrap, .ez-card-wrap, .about-inner, #c-guild-card.outside { background: var(--card-bg) !important; backdrop-filter: blur(${blur}px) !important; -webkit-backdrop-filter: blur(${blur}px) !important; }`;
        }
    }
}

function renderSocials() {
    if (!Array.isArray(customSocials) || !customSocials.length) return;
    const wrap = document.getElementById('c-socials');
    if (!wrap) return;
    wrap.innerHTML = '';
    function esc(s) {
        return String(s || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
    function isImageIcon(ic) {
        return /^(https?:|\/)/i.test(ic || '');
    }
    customSocials.forEach(function (s) {
        if (!s || !s.url) return;
        const a = document.createElement('a');
        const isUrl = /^https?:\/\//i.test(s.url);
        if (s.isCopy || !isUrl) {
            a.href = '#';
            a.onclick = function (e) {
                e.preventDefault();
                if (navigator.clipboard?.writeText) {
                    navigator.clipboard.writeText(s.url).then(() => window.showToast('copied')).catch(() => {});
                }
            };
            a.title = 'Copy: ' + s.url;
        } else {
            a.href = s.url;
            a.target = '_blank';
            a.rel = 'noopener noreferrer';
            a.title = s.label || s.url;
        }
        if (isImageIcon(s.icon)) {
            a.innerHTML = '<img src="' + esc(s.icon) + '" alt="' + esc(s.label || '') + '" style="width:17px;height:17px;object-fit:contain;">';
        } else if (s.icon) {
            let iconName = esc(s.icon).trim().toLowerCase();
            if (iconName === 'riot' || iconName === 'riot games' || iconName === 'riotgames') {
                a.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" width="17" height="17"><path d="M13.468 18.006c.032.553.486.985 1.042.985h5.361c.453 0 .848-.302.993-.736l2.368-7.142c.162-.486-.062-1.02-.533-1.259L13.791 5.34a1.053 1.053 0 0 0-1.42.793l-1.034 6.726a1.053 1.053 0 0 0 .736 1.17l4.025 1.144c.48.136.757.652.593 1.124l-.326.938c-.144.417-.585.666-1.015.545l-4.708-1.336a1.053 1.053 0 0 0-1.246.736l-.612 1.76c-.035.097-.04.202-.016.305v.001zm-4.707.133a1.053 1.053 0 0 0-.275.986l1.243 4.542c.123.45.534.757.997.757h.459c.677 0 1.174-.64.996-1.296l-1.503-5.513a1.053 1.053 0 0 0-.585-.688l-5.69-2.735a1.053 1.053 0 0 0-1.127.155L.68 16.545a1.053 1.053 0 0 0-.11 1.487l4.632 5.385a1.053 1.053 0 0 0 .8.361h1.164a1.053 1.053 0 0 0 1.026-.816l.89-3.818a1.053 1.053 0 0 0-.74-1.246l-2.906-.688a1.053 1.053 0 0 0-1.106.331l-1.12 1.258c-.352.395-1.008.232-1.154-.294l-.794-2.853c-.097-.348.065-.716.386-.86l7.113-3.418v-.001zm1.066-12.875a1.053 1.053 0 0 0-1.166-.812l-6.726 1.034a1.053 1.053 0 0 0-.853 1.341l4.514 14.51c.143.46.611.751 1.09.683l1.838-.26c.556-.079.972-.544.972-1.106v-5.263a1.053 1.053 0 0 0-.824-1.027l-1.292-.26a1.053 1.053 0 0 0-1.229.866l-.161 1.14c-.066.463-.526.77-9.98.665L3.633 7.64c-.1-.403.228-.788.64-.788h2.383c.475 0 .9-.304 1.042-.756l1.378-4.382c.045-.145.023-.306-.062-.43v-.001l.813-.02zM12.981.021a1.053 1.053 0 0 0-1.023.774l-1.034 3.766a1.053 1.053 0 0 0 .762 1.3l2.843.76c.45.12.923-.118 1.077-.55l.896-2.505a1.053 1.053 0 0 0-.583-1.34L13.385.06a1.053 1.053 0 0 0-.404-.04z"/></svg>';
            } else {
                if (!iconName.startsWith('fa-') && !iconName.includes(' ')) iconName = 'fa-brands fa-' + iconName;
                a.innerHTML = '<i class="' + iconName + '" style="font-size:17px"></i>';
            }
        } else {
            a.innerHTML = '<span style="font-size:.78rem;font-weight:600">' + esc((s.label || '?')[0].toUpperCase()) + '</span>';
        }
        wrap.appendChild(a);
    });
    if (window.currentConfig && window.currentConfig.donated && window.currentConfig.donate && window.currentConfig.donate.length > 0) {
        const donateBtn = document.createElement('a');
        donateBtn.href = '#';
        donateBtn.title = 'Ủng hộ (Donate)';
        donateBtn.innerHTML = '<i class="fa-solid fa-heart" style="font-size:17px;color:#ff5e5b"></i>';
        donateBtn.onclick = function (e) {
            e.preventDefault();
            openDonateModal();
        };
        wrap.appendChild(donateBtn);
    }
}

function updateAddFriendUI() {
    const rpcAddBtn = document.getElementById('c-rpc-add-friend');
    if (rpcAddBtn) {
        if (rpcAddFriendLink && rpcAddFriendLink.trim() !== '') {
            let rpcLink = rpcAddFriendLink.trim();
            if (!rpcLink.startsWith('http://') && !rpcLink.startsWith('https://')) {
                rpcLink = 'https://' + rpcLink;
            }
            rpcAddBtn.href = rpcLink;
            rpcAddBtn.style.display = '';
        } else {
            rpcAddBtn.style.display = 'none';
        }
    }
}

async function fetchGuild() {
    const cCards = document.getElementById('c-cards');
    if (!guildInvite) {
        const guildCard = document.getElementById('c-guild-card');
        if (guildCard) guildCard.style.display = 'none';
        if (cCards) cCards.classList.add('single');
        return;
    }
    try {
        const res = await fetch('/api/guild/' + encodeURIComponent(guildInvite));
        const data = await res.json();
        if (data.success && data.guild) {
            const g = data.guild;
            const guildIcon = document.getElementById('c-guild-icon');
            if (guildIcon) guildIcon.src = g.icon || '';
            const guildName = document.getElementById('c-guild-name');
            if (guildName) guildName.textContent = g.name || '—';
            const guildMembers = document.getElementById('c-guild-members');
            if (guildMembers) guildMembers.textContent = (g.approximate_member_count || 0).toLocaleString();
            const guildOnline = document.getElementById('c-guild-online');
            if (guildOnline) guildOnline.textContent = (g.approximate_presence_count || 0).toLocaleString();
            const guildCard = document.getElementById('c-guild-card');
            if (guildCard) {
                if (guildWidgetPlacement === 'outside') {
                    guildCard.classList.add('outside');
                    document.body.appendChild(guildCard);
                } else {
                    guildCard.classList.remove('outside');
                    const cCards = document.getElementById('c-cards');
                    if (cCards) cCards.appendChild(guildCard);
                }
                guildCard.style.display = 'flex';
            }
            const joinBtn = document.getElementById('c-guild-join');
            if (joinBtn) joinBtn.href = 'https://discord.gg/' + guildInvite;
            if (cCards) cCards.classList.remove('single');
        } else {
            const guildCard = document.getElementById('c-guild-card');
            if (guildCard) guildCard.style.display = 'none';
            if (cCards) cCards.classList.add('single');
        }
    } catch (e) {
        const guildCard = document.getElementById('c-guild-card');
        if (guildCard) guildCard.style.display = 'none';
        if (cCards) cCards.classList.add('single');
    }
}

async function incViews() {
    try {
        const r = await fetch('/api/card/view', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        if (r.ok) {
            const d = await r.json();
            return d.views || 0;
        }
    } catch {}
    return null;
}

function animCount(el, tgt) {
    let c = 0;
    const step = Math.ceil(tgt / 60);
    const t = setInterval(() => {
        c += step;
        if (c >= tgt) {
            el.textContent = tgt.toLocaleString();
            clearInterval(t);
        } else el.textContent = Math.floor(c).toLocaleString();
    }, 18);
}

const overlay = document.getElementById('overlay');
let overlayDismissed = false;

function dismissOverlay() {
    if (overlayDismissed) return;
    overlayDismissed = true;
    const audio = document.getElementById('audio');
    if (audio) {
        const savedVolume = audio.volume;
        audio.muted = true;
        audio.play().then(() => {
            audio.pause();
            audio.muted = false;
            audio.volume = savedVolume;
        }).catch(() => {
            audio.muted = false;
        });
    }
    if (window.ytPlayer && window.ytPlayerReady && typeof window.ytPlayer.playVideo === 'function') {
        try {
            window.ytPlayer.mute();
            window.ytPlayer.playVideo();
            setTimeout(() => {
                try {
                    window.ytPlayer.pauseVideo();
                    window.ytPlayer.unMute();
                } catch (e) {}
            }, 300);
        } catch (e) {}
    }
    const spinner = overlay.querySelector('.ov-spinner');
    const spinner2 = overlay.querySelector('.ov-spinner-2');
    const hint = document.getElementById('ov-hint');
    if (hint) {
        hint.textContent = 'entering...';
        hint.style.animation = 'none';
        hint.style.opacity = '.4';
    }
    if (spinner) {
        spinner.style.animationDuration = '2.4s';
    }
    if (spinner2) {
        spinner2.style.animationDuration = '3.8s';
    }
    if (window.musicEnable !== false) {
        tryPlay();
        setSpin(true);
    }
    overlay.style.transition = 'opacity 0.5s ease';
    overlay.style.opacity = '0';
    document.querySelectorAll('.fin').forEach((el, i) => {
        setTimeout(() => el.classList.add('v'), i * 65);
    });
    setTimeout(() => {
        overlay.style.display = 'none';
    }, 500);
}

function addOverlayListeners() {
    if (overlay && !overlay.dismissListenerAdded) {
        overlay.addEventListener('click', dismissOverlay, { once: true });
        overlay.addEventListener('touchstart', dismissOverlay, { once: true });
        overlay.dismissListenerAdded = true;
    }
}

setTimeout(() => {
    if (overlay && overlay.style.display !== 'none' && apiReady === false) {
        apiReady = true;
        const hint = document.getElementById('ov-hint');
        if (hint) {
            hint.textContent = '[ click to start ]';
        }
        overlay.style.pointerEvents = 'auto';
        overlay.style.cursor = 'pointer';
        addOverlayListeners();
    }
}, 30000);

async function updateUI(p) {
    const viewProfileBtn = document.getElementById('c-view-profile');
    if (viewProfileBtn && userId) {
        viewProfileBtn.href = `https://discord.com/users/${userId}`;
    }
    const musicWidgetEl = document.querySelector('.c-music');
    if (musicWidgetEl) {
        const config = window.currentConfig;
        const widgetEnabled = !config || config.musicWidget !== false;
        const localEnabled = config && config.musicEnable !== false;
        const isSpotify = !!p.spotify;
        if (widgetEnabled && (localEnabled || isSpotify)) {
            musicWidgetEl.style.display = 'block';
        } else {
            musicWidgetEl.style.display = 'none';
        }
    }
    const avUrl = avatarOverride || p.avatar;
    if (avUrl) document.getElementById('c-avatar').src = avUrl;
    const decData = p.avatarDecoration;
    const decUrl = avatarDecOverride || decData?.animated || decData?.url || null;
    const decEl = document.getElementById('c-avdec');
    if (decUrl) {
        decEl.onload = function () {
            this.style.display = 'block';
        };
        decEl.onerror = function () {
            this.style.display = 'none';
        };
        decEl.src = decUrl;
    } else {
        decEl.style.display = 'none';
    }
    const nameEl = document.getElementById('c-name');
    const heroName = nameOverride || p.displayName || p.username || 'User';
    const willApplyEffect = layoutConfig && layoutConfig.nameEffect && layoutConfig.nameEffect !== 'none';
    const isEffectActive = nameEffectActive || nameWaveActive;
    if (!isEffectActive) {
        nameEl.textContent = heroName;
    }
    nameEl.dataset.username = p.username || '';
    if (!willApplyEffect) {
        const newNameEl = nameEl.cloneNode(true);
        nameEl.replaceWith(newNameEl);
        newNameEl.addEventListener('click', function () {
            const u = this.dataset.username;
            if (!u) return;
            if (navigator.clipboard?.writeText) {
                navigator.clipboard.writeText(u).then(() => window.showToast('copied')).catch(() => {});
            }
        });
    } else {
        nameEl.onclick = function () {
            const u = this.dataset.username;
            if (!u) return;
            if (navigator.clipboard?.writeText) {
                navigator.clipboard.writeText(u).then(() => window.showToast('copied')).catch(() => {});
            }
        };
    }
    const discordCard = document.getElementById('c-discord-card');
    if (p.avatar) {
        document.getElementById('c-discord-av').src = p.avatar;
        document.getElementById('c-discord-name').textContent = p.displayName || p.username || '—';
        const usernameEl = document.getElementById('c-discord-username');
        if (usernameEl && p.username) usernameEl.textContent = p.username;
        const pronounsEl = document.getElementById('c-discord-pronouns');
        if (pronounsEl) {
            const pr = p.pronouns || '';
            pronounsEl.textContent = pr ? '· ' + pr : '';
        }
        const clanObj = p.clan || p.primary_guild || null;
        const clanTag = (clanObj && clanObj.tag) || p.clan_tag || '';
        const clanEl = document.getElementById('c-clan');
        const cbEl = document.getElementById('c-clan-badge');
        const ctEl = document.getElementById('c-clan-tag');
        if (clanTag && clanEl && ctEl) {
            let cbUrl = p.clan_badge || (clanObj && clanObj.badge) || '';
            const guildId = (clanObj && (clanObj.identity_guild_id || clanObj.identityGuildId || clanObj.guild_id)) || '';
            if (cbUrl && !String(cbUrl).startsWith('http') && guildId) {
                cbUrl = 'https://cdn.discordapp.com/clan-badges/' + guildId + '/' + String(cbUrl).replace(/\.(png|webp|gif)$/i, '') + '.png?size=32';
            }
            if (cbEl) {
                if (cbUrl) {
                    cbEl.style.display = '';
                    cbEl.onerror = function () {
                        if (guildId && cbUrl.includes('clan-badges')) {
                            const hash = String((clanObj && clanObj.badge) || '').replace(/\.(png|webp|gif)$/i, '');
                            if (hash && !hash.startsWith('http')) {
                                this.onerror = function () { this.style.display = 'none'; };
                                this.src = 'https://cdn.discordapp.com/guild-tag-badges/' + guildId + '/' + hash + '.png';
                                return;
                            }
                        }
                        this.style.display = 'none';
                    };
                    cbEl.src = cbUrl;
                } else {
                    cbEl.removeAttribute('src');
                    cbEl.style.display = 'none';
                }
            }
            ctEl.textContent = clanTag;
            clanEl.style.display = 'inline-flex';
            clanEl.title = 'Guild tag: ' + clanTag;
        } else if (clanEl) {
            clanEl.style.display = 'none';
        }
        const statusImgMap = {
            online: 'online.png',
            idle: 'idle.png',
            dnd: 'dnd.png',
            offline: 'offline.png'
        };
        const statusFile = statusImgMap[p.status] || 'offline.png';
        document.getElementById('c-discord-status').src = '/visual/media/badges/' + statusFile;
        const platEl = document.getElementById('c-discord-platforms');
        if (platEl) {
            const plats = [];
            if (p.activeOnDiscordDesktop) plats.push('<i class="fa-solid fa-desktop" title="Desktop"></i>');
            if (p.activeOnDiscordMobile) plats.push('<i class="fa-solid fa-mobile-screen-button" title="Mobile"></i>');
            if (p.activeOnDiscordWeb) plats.push('<i class="fa-solid fa-globe" title="Web Browser"></i>');
            if (plats.length > 0) {
                platEl.innerHTML = plats.join(' ');
                platEl.style.display = 'flex';
            } else {
                platEl.style.display = 'none';
            }
        }
        const acts = p.activities || [];
        const actEl = document.getElementById('c-discord-activity');
        const detEl = document.getElementById('c-discord-detail');
        const artEl = document.getElementById('c-discord-art');
        const customStatusEl = document.getElementById('c-discord-custom-status');
        const customStatusAct = acts.find(a => a.type === 4);
        if (customStatusEl) {
            if (customStatusAct && (customStatusAct.state || customStatusAct.emoji)) {
                let statusText = '';
                if (customStatusAct.emoji) {
                    if (customStatusAct.emoji.id) {
                        statusText += `<img src="https://cdn.discordapp.com/emojis/${customStatusAct.emoji.id}.${customStatusAct.emoji.animated ? 'gif' : 'png'}" style="width:16px;height:16px;vertical-align:middle;margin-right:4px;">`;
                    } else if (customStatusAct.emoji.name) {
                        statusText += customStatusAct.emoji.name + ' ';
                    }
                }
                statusText += customStatusAct.state || '';
                customStatusEl.innerHTML = statusText;
                customStatusEl.style.display = 'flex';
            } else {
                customStatusEl.style.display = 'none';
            }
        }
        const bioSection = document.getElementById('c-discord-bio-section');
        const bioEl = document.getElementById('c-discord-bio');
        if (bioSection && bioEl) {
            if (p.discordBio) {
                bioEl.textContent = p.discordBio;
                bioSection.style.display = 'block';
            } else {
                bioSection.style.display = 'none';
            }
        }
        let noteInterval = null;
        function startNoteEffect(vinylElement) {
            if (noteInterval) return;
            const notes = ['♫', '♪', '♬', '♩'];
            noteInterval = setInterval(() => {
                if (!vinylElement || vinylElement.style.display === 'none') {
                    stopNoteEffect();
                    return;
                }
                const note = document.createElement('div');
                note.className = 'c-floating-note';
                note.textContent = notes[Math.floor(Math.random() * notes.length)];
                
                const rect = vinylElement.getBoundingClientRect();
                const cardEl = document.getElementById('c-discord-card');
                if (!cardEl) return;
                const cardRect = cardEl.getBoundingClientRect();
                
                const startX = rect.left - cardRect.left + rect.width / 2;
                const startY = rect.top - cardRect.top + rect.height / 2;
                
                note.style.left = startX + 'px';
                note.style.top = startY + 'px';
                
                const xDest = (Math.random() * 40 - 20) + 'px';
                const yDest = -(Math.random() * 50 + 40) + 'px';
                const rotDest = (Math.random() * 90 - 45) + 'deg';
                
                note.style.setProperty('--x-dest', xDest);
                note.style.setProperty('--y-dest', yDest);
                note.style.setProperty('--rot-dest', rotDest);
                
                const colors = ['rgba(29, 185, 84, 0.8)', 'rgba(255, 255, 255, 0.8)', 'rgba(255, 255, 255, 0.6)'];
                note.style.color = colors[Math.floor(Math.random() * colors.length)];
                
                cardEl.appendChild(note);
                setTimeout(() => { note.remove(); }, 3000);
            }, 1200);
        }
        function stopNoteEffect() {
            if (noteInterval) {
                clearInterval(noteInterval);
                noteInterval = null;
            }
        }

        const primaryAct = acts.find(a => a.type !== 4);
        const vinylEl = document.getElementById('c-discord-vinyl');
        const vinylArtEl = document.getElementById('c-vinyl-art');
        const activitySectionEl = document.getElementById('c-discord-activity-section');
        
        if (primaryAct) {
            const musicApps = ['spotify', 'apple music', 'youtube music', 'soundcloud', 'tidal', 'music'];
            const isMusicApp = primaryAct.type === 2 || musicApps.some(n => primaryAct.name?.toLowerCase().includes(n));
            
            if (isMusicApp) {
                actEl.textContent = 'Listening to ' + primaryAct.name;
                detEl.textContent = primaryAct.state || primaryAct.details || '';
                if (activitySectionEl) activitySectionEl.style.display = 'none';
                if (vinylEl && vinylArtEl) {
                    let artUrl = '/visual/media/music/image/01.jpg';
                    if (primaryAct.assets?.large_image) {
                        let tempUrl = primaryAct.assets.large_image;
                        if (tempUrl.startsWith('spotify:')) {
                            artUrl = 'https://i.scdn.co/image/' + tempUrl.replace('spotify:', '');
                        } else if (tempUrl.startsWith('mp:external/')) {
                            const parts = tempUrl.split('/https/');
                            if (parts.length > 1) {
                                artUrl = 'https://' + parts[1];
                            }
                        } else if (primaryAct.application_id) {
                            artUrl = `https://cdn.discordapp.com/app-assets/${primaryAct.application_id}/${primaryAct.assets.large_image}.png`;
                        }
                    }
                    vinylArtEl.src = artUrl;
                    vinylEl.style.display = 'flex';
                    startNoteEffect(vinylEl);
                }
            } else {
                actEl.textContent = 'Playing ' + primaryAct.name;
                detEl.textContent = primaryAct.details || primaryAct.state || '';
                if (vinylEl) vinylEl.style.display = 'none';
                stopNoteEffect();
                if (activitySectionEl) activitySectionEl.style.display = 'block';
            }
            if (primaryAct.assets?.large_image) {
                let artUrl = primaryAct.assets.large_image;
                if (artUrl.startsWith('spotify:')) {
                    artUrl = 'https://i.scdn.co/image/' + artUrl.replace('spotify:', '');
                } else if (artUrl.startsWith('mp:external/')) {
                    const parts = artUrl.split('/https/');
                    if (parts.length > 1) {
                        artUrl = 'https://' + parts[1];
                    }
                } else if (primaryAct.application_id) {
                    artUrl = `https://cdn.discordapp.com/app-assets/${primaryAct.application_id}/${primaryAct.assets.large_image}.png`;
                }
                artEl.src = artUrl;
                artEl.style.display = 'block';
                artEl.onerror = function () {
                    this.style.display = 'none';
                };
            } else {
                artEl.style.display = 'none';
            }
        } else {
            const stM = {
                online: 'online',
                idle: 'currently idle',
                dnd: 'do not disturb',
                offline: 'offline'
            };
            actEl.textContent = stM[p.status] || 'offline';
            detEl.textContent = '';
            artEl.style.display = 'none';
            if (vinylEl) vinylEl.style.display = 'none';
            stopNoteEffect();
            if (activitySectionEl) activitySectionEl.style.display = 'block';
        }
        const connEl = document.getElementById('c-discord-connections');
        if (connEl) {
            const conns = p.connectedAccounts || [];
            if (conns.length > 0) {
                let html = '<div class="c-discord-connections-title">Connected Accounts</div>';
                html += '<div class="c-discord-conn-grid">';
                const brandIcons = {
                    spotify: {
                        class: 'fa-brands fa-spotify',
                        color: '#1DB954'
                    },
                    github: {
                        class: 'fa-brands fa-github',
                        color: '#ffffff'
                    },
                    steam: {
                        class: 'fa-brands fa-steam',
                        color: '#00ADEE'
                    },
                    twitch: {
                        class: 'fa-brands fa-twitch',
                        color: '#9146FF'
                    },
                    youtube: {
                        class: 'fa-brands fa-youtube',
                        color: '#FF0000'
                    },
                    twitter: {
                        class: 'fa-brands fa-x-twitter',
                        color: '#1DA1F2'
                    },
                    x: {
                        class: 'fa-brands fa-x-twitter',
                        color: '#ffffff'
                    },
                    facebook: {
                        class: 'fa-brands fa-facebook',
                        color: '#1877F2'
                    },
                    reddit: {
                        class: 'fa-brands fa-reddit',
                        color: '#FF4500'
                    },
                    xbox: {
                        class: 'fa-brands fa-xbox',
                        color: '#107C10'
                    },
                    playstation: {
                        class: 'fa-brands fa-playstation',
                        color: '#003791'
                    },
                    tiktok: {
                        class: 'fa-brands fa-tiktok',
                        color: '#ffffff'
                    },
                    instagram: {
                        class: 'fa-brands fa-instagram',
                        color: '#E1306C'
                    },
                    battlenet: {
                        class: 'fa-brands fa-battle-net',
                        color: '#00AEFF'
                    }
                };
                conns.forEach(c => {
                    const iconInfo = brandIcons[c.type.toLowerCase()] || {
                        class: 'fa-solid fa-link',
                        color: '#ffffff'
                    };
                    let url = '#';
                    if (c.type === 'spotify') url = `https://open.spotify.com/user/${c.id}`;
                    else if (c.type === 'github') url = `https://github.com/${c.name}`;
                    else if (c.type === 'twitch') url = `https://twitch.tv/${c.name}`;
                    else if (c.type === 'youtube') url = `https://youtube.com/channel/${c.id}`;
                    else if (c.type === 'twitter') url = `https://twitter.com/${c.name}`;
                    else if (c.type === 'reddit') url = `https://reddit.com/user/${c.name}`;
                    else if (c.type === 'facebook') url = `https://facebook.com/${c.id}`;
                    const linkAttr = url !== '#' ? `href="${url}" target="_blank" rel="noopener noreferrer"` : 'href="#" onclick="event.preventDefault();"';
                    html += `
                        <a class="c-discord-conn-item" ${linkAttr} title="${c.type}: ${c.name}">
                            <span class="c-discord-conn-icon" style="color: ${iconInfo.color}"><i class="${iconInfo.class}"></i></span>
                            <span class="c-discord-conn-name">${c.name}</span>
                            ${c.verified ? '<span class="c-discord-conn-verified" title="Verified"><i class="fa-solid fa-circle-check"></i></span>' : ''}
                        </a>
                    `;
                });
                html += '</div>';
                connEl.innerHTML = html;
                connEl.style.display = 'flex';
            } else {
                connEl.style.display = 'none';
            }
        }
        const detElGroup = document.getElementById('c-discord-details');
        if (detElGroup) {
            detElGroup.style.display = 'none';
        }
        const ctrlRow = document.getElementById('c-music-ctrl-row');
        const spotRow = document.getElementById('c-spotify-row');
        const activeSpotify = (window.remoteSpotify && window.remoteSpotify.track_id) ? window.remoteSpotify : p.spotify;
        if (activeSpotify) {
            p.spotify = activeSpotify;
            const audio = document.getElementById('audio');
            if (!audio.paused) {
                window.localWasPlaying = true;
                audio.pause();
                syncPlayUI();
            }
            window.isSpotifyActive = true;
            const spotArtEl = document.getElementById('c-spot-art');
            const spotTitleEl = document.getElementById('c-spot-title');
            const spotArtistEl = document.getElementById('c-spot-artist');
            const spotAlbumEl = document.getElementById('c-spot-album');
            const spotAlbumTextEl = document.getElementById('c-spot-album-text');
            const spotLinkEl = document.getElementById('c-spot-link');
            const spotBtnOpen = document.getElementById('c-spot-btn-open');
            const spotBtnLyrics = document.getElementById('c-spot-btn-lyrics');
            const spotBtnShare = document.getElementById('c-spot-btn-share');
            if (spotArtEl) spotArtEl.src = p.spotify.album_art_url || '';
            if (spotTitleEl) spotTitleEl.textContent = p.spotify.song || '—';
            if (spotArtistEl) spotArtistEl.textContent = p.spotify.artist || '—';
            if (p.spotify.album) {
                if (spotAlbumTextEl) spotAlbumTextEl.textContent = p.spotify.album;
                if (spotAlbumEl) spotAlbumEl.style.display = 'flex';
            } else {
                if (spotAlbumEl) spotAlbumEl.style.display = 'none';
            }
            const trackUrl = p.spotify.track_id ? `https://open.spotify.com/track/${p.spotify.track_id}` : null;
            if (spotLinkEl) {
                if (trackUrl) {
                    spotLinkEl.href = trackUrl;
                    spotLinkEl.style.display = 'flex';
                } else {
                    spotLinkEl.style.display = 'none';
                }
            }
            if (spotBtnOpen) {
                if (trackUrl) {
                    spotBtnOpen.href = trackUrl;
                    spotBtnOpen.style.display = 'flex';
                } else {
                    spotBtnOpen.style.display = 'none';
                }
            }
            if (spotBtnLyrics) {
                const elements = {
                    modal: document.getElementById('c-lyrics-modal'),
                    art: document.getElementById('c-lyrics-art'),
                    title: document.getElementById('c-lyrics-title'),
                    artist: document.getElementById('c-lyrics-artist'),
                    content: document.getElementById('c-lyrics-content'),
                    close: document.getElementById('c-lyrics-close')
                };
                spotBtnLyrics.onclick = function (e) {
                    e.stopPropagation();
                    openLyrics(p.spotify.song, p.spotify.artist, p.spotify.album_art_url, elements, function(timeMs) {
                        if (p.spotify && p.spotify.timestamps) {
                            p.spotify.timestamps.start = Date.now() - timeMs;
                        }
                        if (window.ytPlayer && window.ytPlayerReady && typeof window.ytPlayer.seekTo === 'function') {
                            window.ytPlayer.seekTo(timeMs / 1000, true);
                        }
                        syncSpotifyAudio(p, {
                            spotBar: document.getElementById('c-spot-bar'),
                            spotCur: document.getElementById('c-spot-cur'),
                            spotTot: document.getElementById('c-spot-tot'),
                            pfill: document.getElementById('c-pfill'),
                            cur: document.getElementById('c-cur'),
                            tot: document.getElementById('c-tot')
                        }, function(elapsed) {
                            updateLyricsHighlight(elapsed, elements);
                        });
                    });
                };
            }
            if (spotBtnShare) {
                spotBtnShare.onclick = function (e) {
                    e.stopPropagation();
                    if (trackUrl) {
                        openShareModal(trackUrl);
                    }
                };
            }
            if (spotRow) {
                if (trackUrl) {
                    spotRow.onclick = function () {
                        window.open(trackUrl, '_blank');
                    };
                    spotRow.title = "Click để nghe trên Spotify";
                } else {
                    spotRow.onclick = null;
                    spotRow.removeAttribute('title');
                }
            }
            document.getElementById('c-thumb').src = p.spotify.album_art_url || '/visual/media/music/image/01.jpg';
            setSpin(true);
            if (ctrlRow) ctrlRow.style.display = 'none';
            if (spotRow) spotRow.style.display = 'flex';
            const mainTitle = document.getElementById('c-atitle');
            const mainArtWrap = document.querySelector('.c-music-art-wrap');
            const mainPbarRow = document.querySelector('.c-pbar-row');
            const mainRight = document.querySelector('.c-music-right');
            if (mainTitle) mainTitle.style.display = 'none';
            if (mainArtWrap) mainArtWrap.style.display = 'none';
            if (mainPbarRow) mainPbarRow.style.display = 'none';
            if (mainRight) mainRight.style.width = '100%';
            
            const elements = {
                spotBar: document.getElementById('c-spot-bar'),
                spotCur: document.getElementById('c-spot-cur'),
                spotTot: document.getElementById('c-spot-tot'),
                pfill: document.getElementById('c-pfill'),
                cur: document.getElementById('c-cur'),
                tot: document.getElementById('c-tot')
            };
            const lElements = {
                content: document.getElementById('c-lyrics-content')
            };
            syncSpotifyAudio(p, elements, function(elapsed) {
                updateLyricsHighlight(elapsed, lElements);
            });
        } else {
            if (window.isSpotifyActive && !window.remoteSpotify) {
                window.isSpotifyActive = false;
                clearSpotifySync();
                const mainTitle = document.getElementById('c-atitle');
                const mainArtWrap = document.querySelector('.c-music-art-wrap');
                const mainPbarRow = document.querySelector('.c-pbar-row');
                const mainRight = document.querySelector('.c-music-right');
                if (mainTitle) mainTitle.style.display = '';
                if (mainArtWrap) mainArtWrap.style.display = '';
                if (mainPbarRow) mainPbarRow.style.display = '';
                if (mainRight) mainRight.style.width = '';
                if (ctrlRow) ctrlRow.style.display = 'flex';
                if (spotRow) {
                    spotRow.style.display = 'none';
                    spotRow.onclick = null;
                    spotRow.removeAttribute('title');
                }
                const spotBtnLyrics = document.getElementById('c-spot-btn-lyrics');
                const spotBtnShare = document.getElementById('c-spot-btn-share');
                if (spotBtnLyrics) spotBtnLyrics.onclick = null;
                if (spotBtnShare) spotBtnShare.onclick = null;
                loadTrack(currentIndex, !!window.localWasPlaying);
                window.localWasPlaying = false;
                setSpin(false);
            }
        }
        discordCard.style.display = 'flex';
    }
    const bios = (customBios && customBios.length > 0) ? customBios : [' '];
    let bi = 0;
    let bci = 0;
    let bdl = false;
    const bel = document.getElementById('c-bio');
    if (window.bioTimer) clearTimeout(window.bioTimer);
    function tick() {
        const t = bios[bi] || '';
        bel.textContent = bdl ? t.substring(0, --bci) : t.substring(0, ++bci);
        if (!bdl && bci === t.length) {
            bdl = true;
            window.bioTimer = setTimeout(tick, 2400);
            return;
        }
        if (bdl && bci === 0) {
            bdl = false;
            bi = (bi + 1) % bios.length;
            window.bioTimer = setTimeout(tick, 500);
            return;
        }
        window.bioTimer = setTimeout(tick, bdl ? 26 : 52);
    }
    tick();
    try {
        const badgesEl = document.getElementById('c-badges');
        if (badgesEl) {
            badgesEl.innerHTML = '';
            try {
                const bRes = await fetch('/api/discord/badges?id=' + userId);
                if (bRes.ok) {
                    const bData = await bRes.json();
                    if (bData.success && bData.badges) {
                        badgesEl.innerHTML = '';
                        bData.badges.forEach(b => {
                            const wrap = document.createElement('div');
                            wrap.style.cssText = 'position:relative;display:inline-flex;';
                            const img = document.createElement('img');
                            img.onerror = function () {
                                wrap.style.display = 'none';
                            };
                            img.src = b.icon;
                            img.alt = b.label || '';
                            wrap.appendChild(img);
                            const tip = document.createElement('div');
                            tip.style.cssText = 'position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%) translateY(4px);background:rgba(6,8,7,.96);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:5px 10px;font-size:.6rem;font-weight:500;color:#fff;white-space:nowrap;pointer-events:none;opacity:0;transition:opacity .18s,transform .18s;z-index:50;backdrop-filter:blur(12px);';
                            tip.textContent = b.label || '';
                            wrap.appendChild(tip);
                            wrap.onmouseenter = function () {
                                tip.style.opacity = '1';
                                tip.style.transform = 'translateX(-50%) translateY(0)';
                            };
                            wrap.onmouseleave = function () {
                                tip.style.opacity = '0';
                                tip.style.transform = 'translateX(-50%) translateY(4px)';
                            };
                            badgesEl.appendChild(wrap);
                        });
                    }
                }
            } catch (e) {}
        }
    } catch (e) {}
    if (willApplyEffect && !nameEffectActive && !nameWaveActive) {
        applyNameEffect(layoutConfig.nameEffect);
    }
}

async function pollSpotifyRemote() {
    try {
        const res = await fetch('/api/spotify/remote/playback-state', { cache: 'no-store' });
        if (!res.ok) {
            if (res.status === 401) window.remoteSpotify = null;
            return;
        }
        const data = await res.json();
        if (data && data.item && data.item.id) {
            const durationMs = Number(data.item.durationMs) || 0;
            const progressMs = Math.max(0, Math.min(Number(data.progressMs) || 0, durationMs || 1e15));
            const now = Date.now();
            window.remoteSpotify = {
                track_id: data.item.id,
                song: data.item.name || '',
                artist: data.item.artists || '',
                album: data.item.albumName || '',
                album_art_url: data.item.albumArt || '',
                timestamps: {
                    start: now - progressMs,
                    end: now - progressMs + (durationMs || 1)
                },
                isPlaying: data.isPlaying !== false,
                source: 'remote'
            };
            await updateUI(Object.assign({}, currentPresence, { spotify: window.remoteSpotify }));
        } else {
            window.remoteSpotify = null;
            if (window.isSpotifyActive && !(currentPresence && currentPresence.spotify)) {
                await updateUI(currentPresence);
            }
        }
    } catch (_) {}
}

function startSpotifyRemotePoll() {
    if (window.__spotifyRemotePoll) clearInterval(window.__spotifyRemotePoll);
    pollSpotifyRemote();
    window.__spotifyRemotePoll = setInterval(pollSpotifyRemote, 4000);
}

async function fetchPresenceData() {
    try {
        const [presenceRes, viewCount] = await Promise.all([
            fetch('/api/presence/' + userId).then(r => r.json()).catch(() => null),
            incViews()
        ]);
        if (presenceRes) {
            updatePresenceProfile(presenceRes);
            await updateUI(currentPresence);
        } else {
            await updateUI({
                avatar: "https://cdn.discordapp.com/embed/avatars/0.png",
                avatarDecoration: null,
                displayName: "Offline User",
                username: "offline",
                status: "offline",
                activities: [],
                public_flags: 0,
                activeOnDiscordDesktop: false,
                activeOnDiscordMobile: false,
                activeOnDiscordWeb: false,
                clan: null
            });
        }
        if (viewCount !== null) {
            animCount(document.getElementById('views'), viewCount);
            document.getElementById('c-views').textContent = viewCount.toLocaleString();
        }
        fetchGuild();
    } catch (e) {
        console.error(e);
    } finally {
        apiReady = true;
        const hint = document.getElementById('ov-hint');
        if (hint) {
            hint.textContent = '[ click to start ]';
        }
        overlay.style.pointerEvents = 'auto';
        overlay.style.cursor = 'pointer';
        addOverlayListeners();
    }
}

async function initApp() {
    try {
        const res = await fetch('/api/config');
        if (res.ok) {
            const config = await res.json();
            window.currentConfig = config;
            if (config.userId) userId = config.userId;
            if (config.backgroundUrl !== undefined) backgroundUrl = config.backgroundUrl;
            if (config.backgroundBlur !== undefined) backgroundBlur = config.backgroundBlur;
            if (backgroundUrl || backgroundBlur >= 0) window.applyBackground(backgroundUrl);
            if (config.avatarOverride !== undefined) avatarOverride = config.avatarOverride;
            if (config.avatarDecOverride !== undefined) avatarDecOverride = config.avatarDecOverride;
            if (config.nameOverride !== undefined) nameOverride = config.nameOverride;
            const ovName = document.getElementById('ov-name');
            if (ovName) ovName.textContent = '@ ' + (nameOverride || 'bio').toLowerCase();
            titleText = '@' + (nameOverride || 'bio').toLowerCase();
            titleIndex = 0;
            titleDirection = false;
            if (config.customBios !== undefined) customBios = config.customBios;
            if (config.customCss !== undefined) {
                let cssEl = document.getElementById('user-custom-css');
                if (!cssEl) {
                    cssEl = document.createElement('style');
                    cssEl.id = 'user-custom-css';
                    document.head.appendChild(cssEl);
                }
                cssEl.textContent = config.customCss;
            }
            if (config.customSocials) customSocials = config.customSocials;
            if (config.guildInvite !== undefined) guildInvite = config.guildInvite;
            if (config.rpcAddFriendLink !== undefined) rpcAddFriendLink = config.rpcAddFriendLink;
            updateAddFriendUI();
            if (config.guildWidgetPlacement !== undefined) guildWidgetPlacement = config.guildWidgetPlacement;
            if (config.locationText !== undefined) {
                document.getElementById('c-location').textContent = config.locationText;
            } else if (config.layout && config.layout.locationText) {
                document.getElementById('c-location').textContent = config.layout.locationText;
            }
            if (config.musicRandom !== undefined) isMusicRandom = config.musicRandom;
            if (config.musicEnable !== undefined) window.musicEnable = config.musicEnable;
            else window.musicEnable = false;
            setupPlayer(config);
            const localLyricsBtn = document.getElementById('c-local-lyrics');
            const audio = document.getElementById('audio');
            if (localLyricsBtn && audio) {
                const elements = {
                    modal: document.getElementById('c-lyrics-modal'),
                    art: document.getElementById('c-lyrics-art'),
                    title: document.getElementById('c-lyrics-title'),
                    artist: document.getElementById('c-lyrics-artist'),
                    content: document.getElementById('c-lyrics-content'),
                    close: document.getElementById('c-lyrics-close')
                };
                localLyricsBtn.onclick = () => {
                    const currentTrack = getCurrentTrack();
                    if (!currentTrack) return;
                    openLyrics(currentTrack.title, currentTrack.artist || 'Unknown', currentTrack.cover || '', elements, (timeMs) => {
                        audio.currentTime = timeMs / 1000;
                    });
                };
                audio.addEventListener('timeupdate', () => {
                    if (!window.isSpotifyActive) {
                        const lElements = {
                            content: document.getElementById('c-lyrics-content')
                        };
                        updateLyricsHighlight(audio.currentTime * 1000, lElements);
                    }
                });
            }
            const localShareBtn = document.getElementById('c-local-share');
            if (localShareBtn) {
                localShareBtn.onclick = () => {
                    const currentTrack = getCurrentTrack();
                    if (!currentTrack) return;
                    const absUrl = window.location.origin + currentTrack.src;
                    openShareModal(absUrl);
                };
            }
            if (config.layout) applyLayout(config.layout);
            applyStyleConfig(config.style);
            applyCustomSettings(config);
            if (config.donated && config.donate && config.donate.length > 0) {
                const floatDonateBtn = document.getElementById('c-float-donate-btn');
                if (floatDonateBtn) floatDonateBtn.style.display = 'flex';
            }
        }
    } catch (e) {
        console.error('Failed to load config', e);
    }
    renderSocials();
    fetchPresenceData();
    startSpotifyRemotePoll();
    connectLanyardWs(userId, function(presence) {
        updateUI(presence);
    });
    setInterval(async () => {
        try {
            const res = await fetch('/api/config');
            if (res.ok) {
                const config = await res.json();
                window.currentConfig = config;
                if (JSON.stringify(customBios) !== JSON.stringify(config.customBios)) {
                    customBios = config.customBios || [];
                }
                if (JSON.stringify(customSocials) !== JSON.stringify(config.customSocials)) {
                    customSocials = config.customSocials || [];
                    renderSocials();
                }
                if (guildInvite !== config.guildInvite) {
                    guildInvite = config.guildInvite || '';
                    fetchGuild();
                }
                if (rpcAddFriendLink !== config.rpcAddFriendLink) {
                    rpcAddFriendLink = config.rpcAddFriendLink || '';
                    updateAddFriendUI();
                }
                if (guildWidgetPlacement !== config.guildWidgetPlacement) {
                    guildWidgetPlacement = config.guildWidgetPlacement || 'inside';
                    fetchGuild();
                }
                if (config.locationText !== undefined && document.getElementById('c-location').textContent !== config.locationText) {
                    document.getElementById('c-location').textContent = config.locationText;
                }
                if (config.customCss !== undefined) {
                    let cssEl = document.getElementById('user-custom-css');
                    if (cssEl && cssEl.textContent !== config.customCss) cssEl.textContent = config.customCss;
                }
                applyStyleConfig(config.style);
                applyCustomSettings(config);
                const floatDonateBtn = document.getElementById('c-float-donate-btn');
                if (floatDonateBtn) {
                    floatDonateBtn.style.display = (config.donated && config.donate && config.donate.length > 0) ? 'flex' : 'none';
                }
            }
        } catch (e) {}
    }, 15000);
}

function openShareModal(linkUrl) {
    const modal = document.getElementById('c-share-modal');
    const qrImg = document.getElementById('c-share-qrcode');
    const linkInput = document.getElementById('c-share-link-val');
    const copyBtn = document.getElementById('c-share-copy-btn');
    if (!modal || !qrImg || !linkInput) return;
    qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(linkUrl)}`;
    linkInput.value = linkUrl;
    if (copyBtn) copyBtn.textContent = 'Sao chép';
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.style.opacity = '1';
        modal.style.pointerEvents = 'auto';
        if (modal.firstElementChild) {
            modal.firstElementChild.style.transform = 'scale(1)';
        }
    }, 10);
}

function closeShareModal() {
    const modal = document.getElementById('c-share-modal');
    if (!modal) return;
    modal.style.opacity = '0';
    modal.style.pointerEvents = 'none';
    if (modal.firstElementChild) {
        modal.firstElementChild.style.transform = 'scale(0.9)';
    }
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300);
}

function initTheme() {
    const themeToggleBtn = document.getElementById('theme-toggle');
    if (!themeToggleBtn) return;
    let currentTheme = localStorage.getItem('theme') || 'system';
    function applyTheme(theme) {
        let actualTheme = theme;
        if (theme === 'system') {
            actualTheme = window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
        }
        document.documentElement.setAttribute('data-theme', actualTheme);
        if (theme === 'dark') {
            themeToggleBtn.innerHTML = '<i class="fa-solid fa-moon"></i>';
            themeToggleBtn.title = 'Chế độ: Tối';
        } else if (theme === 'light') {
            themeToggleBtn.innerHTML = '<i class="fa-solid fa-sun"></i>';
            themeToggleBtn.title = 'Chế độ: Sáng';
        } else {
            themeToggleBtn.innerHTML = '<i class="fa-solid fa-circle-half-stroke"></i>';
            themeToggleBtn.title = 'Chế độ: Hệ thống';
        }
    }
    themeToggleBtn.addEventListener('click', () => {
        if (currentTheme === 'system') {
            currentTheme = 'dark';
        } else if (currentTheme === 'dark') {
            currentTheme = 'light';
        } else {
            currentTheme = 'system';
        }
        localStorage.setItem('theme', currentTheme);
        applyTheme(currentTheme);
    });
    window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => {
        if (currentTheme === 'system') {
            applyTheme('system');
        }
    });
    applyTheme(currentTheme);
}

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    const closeBtn = document.getElementById('c-lyrics-close');
    const modal = document.getElementById('c-lyrics-modal');
    if (closeBtn) {
        closeBtn.onclick = () => closeLyrics({
            modal
        });
    }
    if (modal) {
        modal.onclick = (e) => {
            if (e.target === modal) closeLyrics({
                modal
            });
        };
    }
    const shareClose = document.getElementById('c-share-close');
    const shareModal = document.getElementById('c-share-modal');
    if (shareClose) {
        shareClose.onclick = () => closeShareModal();
    }
    if (shareModal) {
        shareModal.onclick = (e) => {
            if (e.target === shareModal) closeShareModal();
        };
    }
    const shareCopyBtn = document.getElementById('c-share-copy-btn');
    if (shareCopyBtn) {
        shareCopyBtn.onclick = () => {
            const linkInput = document.getElementById('c-share-link-val');
            if (linkInput && navigator.clipboard?.writeText) {
                navigator.clipboard.writeText(linkInput.value)
                    .then(() => {
                        shareCopyBtn.textContent = 'Đã chép!';
                        if (window.showToast) {
                            window.showToast('copied', 'Đã sao chép!', 'Đã sao chép liên kết vào clipboard.');
                        }
                    })
                    .catch(err => console.error('Copy link failed:', err));
            }
        };
    }
    initDonate();
    initApp();
});
